import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from tkinter import Tk, filedialog, simpledialog, messagebox
from docx import Document
from docx.shared import Inches
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
import datetime
import os
import subprocess
import shutil
import tempfile
import sys

def get_resource_path(filename):
    """Get absolute path for a file bundled with the script or .exe"""
    if getattr(sys, 'frozen', False):
        base_path = sys._MEIPASS  # For PyInstaller
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, filename)

def center_cell(cell):
    """Center-align text in a table cell."""
    for paragraph in cell.paragraphs:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER

def generate_pie_chart(df, output_path):
    """Generate and save pie chart of result distribution."""
    result_counts = df['Result'].value_counts()
    plt.figure(figsize=(4, 4))
    plt.pie(result_counts, labels=result_counts.index, autopct='%1.1f%%', startangle=90)
    plt.title('Security Level Distribution')
    plt.savefig(output_path, bbox_inches='tight')
    plt.close()

def open_template_for_editing(template_path):
    """Copy template to temp, open in Word, allow user to edit."""
    temp_template = os.path.join(tempfile.gettempdir(), "editable_template.docx")
    shutil.copyfile(template_path, temp_template)
    try:
        subprocess.Popen(['start', temp_template], shell=True)
    except Exception as e:
        messagebox.showerror("Error", f"Could not open template:\n{e}")
        return None
    messagebox.showinfo("Edit Template", "The template has been opened in Word.\nPlease make changes and save it.\nClick OK when you're done.")
    return temp_template

def main():
    root = Tk()
    root.withdraw()

    # Select CSV file
    messagebox.showinfo("CIS Report Tool", "Select the CSV file for report generation.")
    csv_path = filedialog.askopenfilename(title="Select CSV File", filetypes=[("CSV Files", "*.csv")])
    if not csv_path:
        messagebox.showerror("Error", "No CSV file selected.")
        return

    # Load and validate CSV
    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        messagebox.showerror("CSV Error", f"Failed to read CSV:\n{e}")
        return

    if not {'Title', 'Result'}.issubset(df.columns):
        messagebox.showerror("Invalid Format", "CSV must include 'Title' and 'Result' columns.")
        return

    # Get agent/client name
    agent_name = simpledialog.askstring("Agent Info", "Enter Agent (Client) Name:")
    if not agent_name:
        messagebox.showerror("Missing Info", "Agent name is required.")
        return

    # Use local template (same directory as script)
    default_template = get_resource_path("CIS_Template.docx")

    # Ask user to edit the template
    use_custom = messagebox.askyesno("Template Editing", "Do you want to edit the default template before using it?")
    if use_custom:
        template_path = open_template_for_editing(default_template)
        if not template_path:
            return
    else:
        template_path = default_template

    try:
        doc = Document(template_path)
    except Exception as e:
        messagebox.showerror("Template Error", f"Failed to load Word template:\n{e}")
        return

    # Add heading for agent
    doc.add_heading(f"Agent: {agent_name}", level=1).alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Add pie chart
    chart_file = os.path.join(tempfile.gettempdir(), "temp_pie_chart.png")
    generate_pie_chart(df, chart_file)
    doc.add_picture(chart_file, width=Inches(4.5))
    doc.add_paragraph("\n")

    # Create results table
    table = doc.add_table(rows=1, cols=4)
    try:
        table.style = 'Table Grid'
    except KeyError:
        table.style = None
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    headers = ['S.No', 'Setting', 'Result', 'Reason']
    hdr_cells = table.rows[0].cells
    for i, header in enumerate(headers):
        hdr_cells[i].text = header
        center_cell(hdr_cells[i])

    for idx, (_, row) in enumerate(df.iterrows(), start=1):
        setting = str(row['Title'])
        result = str(row['Result'])
        rationale = str(row['Rationale']) if 'Rationale' in row and pd.notnull(row['Rationale']) else "N/A"

        row_cells = table.add_row().cells
        row_cells[0].text = str(idx)
        row_cells[1].text = setting
        row_cells[2].text = result
        row_cells[3].text = rationale

        for cell in row_cells:
            center_cell(cell)

    # Save the report
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    file_name = f"{agent_name}-{today}-configureassessment-report.docx"
    doc.save(file_name)

    # Clean up
    if os.path.exists(chart_file):
        os.remove(chart_file)

    messagebox.showinfo("Success", f"Report saved as:\n{file_name}")

if __name__ == "__main__":
    main()

